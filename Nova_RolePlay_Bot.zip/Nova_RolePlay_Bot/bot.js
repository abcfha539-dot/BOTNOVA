require('dotenv').config();
const fs = require('node:fs');
const path = require('node:path');
const { Client, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionsBitField } = require('discord.js');
const Gamedig = require('gamedig');
const config = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'));
const store = require('./lib/store');
if (!process.env.DISCORD_TOKEN) throw new Error('ضع DISCORD_TOKEN داخل ملف .env');
const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers, GatewayIntentBits.GuildMessages], partials: [Partials.Channel] });
const color = Number.parseInt((config.brand.color || '#D71920').replace('#',''), 16);
const embed = (title, description) => new EmbedBuilder().setColor(color).setTitle(title).setDescription(description).setFooter({ text: config.brand.footer || config.brand.name });
const hasStaff = member => member.permissions.has(PermissionsBitField.Flags.Administrator) || [config.roles.staffRoleId, config.roles.adminRoleId].filter(Boolean).some(id => member.roles.cache.has(id));
async function log(guild, title, description) { const id=config.channels.logsChannelId; if(!id) return; const ch=await guild.channels.fetch(id).catch(()=>null); if(ch?.isTextBased()) await ch.send({embeds:[embed(title,description)]}).catch(()=>{}); }
function ticketMenu(){ return new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId('nova_ticket_create').setPlaceholder('اختار نوع التذكرة').addOptions(config.tickets.types.slice(0,25).map((name,i)=>({label:name.slice(0,100),value:`type_${i}`,description:`فتح تذكرة: ${name}`.slice(0,100)})))); }
client.once('ready',()=>{ console.log(`Nova RolePlay bot online: ${client.user.tag}`); client.user.setActivity('Nova RolePlay | MTA'); });
client.on('guildMemberAdd', async member=>{ const id=config.channels.welcomeChannelId; if(!id)return; const ch=await member.guild.channels.fetch(id).catch(()=>null); if(ch?.isTextBased()) await ch.send({embeds:[embed('أهلًا بك في Nova RolePlay',`نورت السيرفر ${member}\nنتمنى لك وقتًا ممتعًا!`).setThumbnail(member.user.displayAvatarURL())]}).catch(()=>{}); });
client.on('guildMemberRemove', async member=>{ const id=config.channels.leaveChannelId; if(!id)return; const ch=await member.guild.channels.fetch(id).catch(()=>null); if(ch?.isTextBased()) await ch.send({embeds:[embed('مغادرة عضو',`غادر ${member.user.tag} السيرفر.`)]}).catch(()=>{}); });
client.on('interactionCreate', async interaction=>{
 try {
  if(interaction.isChatInputCommand()) {
   const {commandName}=interaction;
   if(commandName==='dm') {
    if(!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) return interaction.reply({content:'الأمر للمصرّح لهم فقط.',ephemeral:true});
    const user=interaction.options.getUser('member'); const message=interaction.options.getString('message');
    if(user.bot) return interaction.reply({content:'ما ينفعش تبعت رسالة خاصة لبوت.',ephemeral:true});
    if(user.id===interaction.user.id) return interaction.reply({content:'اختار لاعبًا آخر.',ephemeral:true});
    try { await user.send({embeds:[embed('رسالة من إدارة Nova RolePlay',message)]});
      await interaction.reply({content:`تم إرسال الرسالة الخاصة إلى ${user.tag}.`,ephemeral:true});
      await log(interaction.guild,'إرسال رسالة خاصة',`المرسل: ${interaction.user.tag}\nالمستلم: ${user.tag} (${user.id})\nالمحتوى: ${message.slice(0,800)}`);
    } catch { await interaction.reply({content:'تعذّر إرسال الخاص؛ قد تكون الرسائل الخاصة مغلقة لدى اللاعب.',ephemeral:true}); }
    return;
   }
   if(commandName==='userinfo') {
    const user=interaction.options.getUser('member')||interaction.user; const member=await interaction.guild.members.fetch(user.id).catch(()=>null);
    const joined=member?.joinedAt?Math.floor(member.joinedAt.getTime()/1000):null; const created=Math.floor(user.createdTimestamp/1000);
    const roles=member?member.roles.cache.filter(r=>r.id!==interaction.guild.id).map(r=>r.toString()).slice(0,15).join(', ')||'لا توجد':'العضو غير موجود حاليًا في السيرفر';
    const e=embed('معلومات العضو',`**الاسم:** ${user.tag}\n**المنشن:** ${user}\n**المعرف:** \`${user.id}\`\n**تاريخ إنشاء الحساب:** <t:${created}:F>\n**انضم للسيرفر:** ${joined?`<t:${joined}:F>`:'غير متاح'}\n**الرتب:** ${roles}`).setThumbnail(user.displayAvatarURL({size:256}));
    return interaction.reply({embeds:[e],ephemeral:true});
   }
   if(commandName==='serverinfo') {
    const g=interaction.guild; const owner=await g.fetchOwner().catch(()=>null); const created=Math.floor(g.createdTimestamp/1000);
    return interaction.reply({embeds:[embed(`معلومات ${g.name}`,`**المالك:** ${owner||'غير متاح'}\n**المعرف:** \`${g.id}\`\n**الأعضاء:** ${g.memberCount}\n**القنوات:** ${g.channels.cache.size}\n**الرتب:** ${g.roles.cache.size}\n**تاريخ الإنشاء:** <t:${created}:F>`).setThumbnail(g.iconURL({size:256}))]});
   }
   if(commandName==='avatar') { const user=interaction.options.getUser('member')||interaction.user; return interaction.reply({embeds:[embed(`صورة ${user.tag}`,`[فتح الصورة بالحجم الأصلي](${user.displayAvatarURL({size:1024})})`).setImage(user.displayAvatarURL({size:1024}))]}); }
   if(commandName==='poll') {
    const question=interaction.options.getString('question'); const a=interaction.options.getString('option1'); const b=interaction.options.getString('option2');
    const msg=await interaction.channel.send({embeds:[embed(`📊 ${question}`,`🇦 **${a}**\n🇧 **${b}**\n\nصوّت باستخدام التفاعلات بالأسفل.`).setFooter({text:`بواسطة ${interaction.user.tag}`})]});
    await msg.react('🇦'); await msg.react('🇧'); return interaction.reply({content:'تم نشر التصويت.',ephemeral:true});
   }
   if(commandName==='lock'||commandName==='unlock') {
    const lock=commandName==='lock'; await interaction.channel.permissionOverwrites.edit(interaction.guild.roles.everyone,{SendMessages:lock?false:null});
    await interaction.reply({embeds:[embed(lock?'🔒 تم قفل القناة':'🔓 تم فتح القناة',`${interaction.channel} — بواسطة ${interaction.user}`)]});
    await log(interaction.guild,lock?'قفل قناة':'فتح قناة',`${interaction.user.tag} — ${interaction.channel}`); return;
   }
   if(commandName==='slowmode') { const seconds=interaction.options.getInteger('seconds'); await interaction.channel.setRateLimitPerUser(seconds,`بواسطة ${interaction.user.tag}`); return interaction.reply({content:seconds?`تم ضبط الـ Slowmode على ${seconds} ثانية.`:'تم إلغاء الـ Slowmode.'}); }
   if(commandName==='role-add'||commandName==='role-remove') {
    const user=interaction.options.getUser('member'); const role=interaction.options.getRole('role');
    if(role.managed || role.position>=interaction.guild.members.me.roles.highest.position) return interaction.reply({content:'لا أستطيع إدارة هذه الرتبة. ارفع رتبة البوت فوقها وتأكد أنها ليست رتبة مُدارة.',ephemeral:true});
    const member=await interaction.guild.members.fetch(user.id).catch(()=>null); if(!member) return interaction.reply({content:'العضو غير موجود في السيرفر.',ephemeral:true});
    if(member.id===interaction.guild.ownerId || member.roles.highest.position>=interaction.member.roles.highest.position) return interaction.reply({content:'لا يمكن تعديل رتب هذا العضو بسبب ترتيب الرتب.',ephemeral:true});
    if(commandName==='role-add') await member.roles.add(role,`بواسطة ${interaction.user.tag}`); else await member.roles.remove(role,`بواسطة ${interaction.user.tag}`);
    await interaction.reply({content:`تم ${commandName==='role-add'?'إعطاء':'سحب'} رتبة ${role} من ${user}.`}); await log(interaction.guild,'تعديل رتبة',`${interaction.user.tag} — ${commandName} — ${role.name} — ${user.tag}`); return;
   }
   if(commandName==='setup-ticket') { if(!interaction.memberPermissions?.has(PermissionsBitField.Flags.Administrator)) return interaction.reply({content:'الأمر للمسؤولين فقط.',ephemeral:true}); await interaction.reply({content:'تم إرسال لوحة التذاكر.',ephemeral:true}); await interaction.channel.send({embeds:[embed(config.tickets.panelTitle,config.tickets.panelDescription)],components:[ticketMenu()]}); return; }
   if(commandName==='ticket-close') { if(!interaction.channel?.topic?.includes('NOVA_TICKET')) return interaction.reply({content:'الأمر ده داخل تذكرة فقط.',ephemeral:true}); if(!hasStaff(interaction.member) && !interaction.channel.topic.includes(`OWNER:${interaction.user.id}`)) return interaction.reply({content:'مش معاك صلاحية تقفل التذكرة دي.',ephemeral:true}); await interaction.reply({content:'التذكرة هتتقفل بعد 5 ثواني.'}); await log(interaction.guild,'إغلاق تذكرة',`${interaction.user.tag} أغلق ${interaction.channel.name}`); setTimeout(()=>interaction.channel.delete().catch(()=>{}),5000); return; }
   if(commandName==='server-status') { if(!config.mta.enabled) return interaction.reply({embeds:[embed('حالة سيرفر MTA','حالة الربط غير مفعّلة بعد. عدّل إعدادات mta في config.json ثم أعد تشغيل البوت.')],ephemeral:true}); await interaction.deferReply(); try { const state=await Gamedig.query({type:config.mta.type||'mtasa',host:config.mta.host,port:Number(config.mta.port)}); return interaction.editReply({embeds:[embed('Nova RolePlay | MTA Status',`🟢 **الحالة:** Online\n👥 **اللاعبون:** ${state.players.length}/${state.maxplayers}\n🗺️ **الخريطة:** ${state.map||'غير معروف'}\n🌐 **السيرفر:** ${config.mta.host}:${config.mta.port}`)]}); } catch { return interaction.editReply({embeds:[embed('Nova RolePlay | MTA Status','🔴 السيرفر Offline أو بيانات الاتصال غير صحيحة.')]}); } }
   if(commandName==='warn') { const user=interaction.options.getUser('member'); const reason=interaction.options.getString('reason'); const db=store.read(); db.warnings[user.id]??=[]; db.warnings[user.id].push({reason,by:interaction.user.id,at:new Date().toISOString()}); store.write(db); await interaction.reply({embeds:[embed('تم تسجيل تحذير',`العضو: ${user}\nالسبب: ${reason}\nعدد التحذيرات: ${db.warnings[user.id].length}`)]}); await log(interaction.guild,'تحذير جديد',`${user.tag} — ${reason} — بواسطة ${interaction.user.tag}`); return; }
   if(commandName==='warnings') { const user=interaction.options.getUser('member'); const list=store.read().warnings[user.id]||[]; return interaction.reply({embeds:[embed(`تحذيرات ${user.tag}`,list.length?list.map((w,i)=>`${i+1}. ${w.reason} — <@${w.by}>`).join('\n'):'لا توجد تحذيرات مسجلة.')],ephemeral:true}); }
   if(commandName==='clear') { const amount=interaction.options.getInteger('amount'); const deleted=await interaction.channel.bulkDelete(amount,true); await interaction.reply({content:`تم مسح ${deleted.size} رسالة.`,ephemeral:true}); await log(interaction.guild,'مسح رسائل',`${interaction.user.tag} مسح ${deleted.size} رسالة في ${interaction.channel}`); return; }
   if(commandName==='kick'||commandName==='ban') { const user=interaction.options.getUser('member'); const reason=interaction.options.getString('reason')||'لم يتم تحديد سبب'; const member=await interaction.guild.members.fetch(user.id).catch(()=>null); if(!member) return interaction.reply({content:'العضو غير موجود في السيرفر.',ephemeral:true}); if(commandName==='kick') await member.kick(reason); else await member.ban({reason}); await interaction.reply({content:`تم ${commandName==='kick'?'طرد':'حظر'} ${user.tag}.`}); await log(interaction.guild,commandName==='kick'?'طرد عضو':'حظر عضو',`${user.tag} — ${reason} — بواسطة ${interaction.user.tag}`); return; }
   if(commandName==='announce') { const ch=interaction.options.getChannel('channel'); const message=interaction.options.getString('message'); await ch.send({embeds:[embed('Nova RolePlay | إعلان',message)]}); return interaction.reply({content:`تم إرسال الإعلان في ${ch}.`,ephemeral:true}); }
   if(commandName==='help') {
    return interaction.reply({embeds:[embed('Nova RolePlay | قائمة الأوامر',
      '**للأعضاء**\n`/help` `/ping` `/botinfo` `/membercount` `/userinfo` `/serverinfo` `/avatar` `/roleinfo` `/channelinfo` `/suggest` `/report` `/remind` `/dm-optin` `/dm-optout` `/server-status`\n\n**للإدارة والمشرفين حسب الصلاحيات**\n`/warn` `/warnings` `/clear` `/kick` `/ban` `/timeout` `/untimeout` `/nickname` `/role-add` `/role-remove` `/lock` `/unlock` `/slowmode` `/poll` `/announce` `/say` `/embed` `/giveaway` `/dm` `/dm-all` `/setup-ticket` `/ticket-panel` `/ticket-close`')],ephemeral:true});
   }
   if(commandName==='ping') return interaction.reply({content:`🏓 Pong! زمن الاستجابة: ${client.ws.ping}ms`,ephemeral:true});
   if(commandName==='botinfo') {
    const uptime=Math.floor(client.uptime/1000); const days=Math.floor(uptime/86400), hours=Math.floor(uptime%86400/3600), mins=Math.floor(uptime%3600/60);
    return interaction.reply({embeds:[embed('معلومات Nova Bot',`**الاسم:** ${client.user.tag}\n**السيرفرات:** ${client.guilds.cache.size}\n**وقت التشغيل:** ${days} يوم، ${hours} ساعة، ${mins} دقيقة\n**Ping:** ${client.ws.ping}ms\n**الإصدار:** discord.js v14` ).setThumbnail(client.user.displayAvatarURL())],ephemeral:true});
   }
   if(commandName==='membercount') return interaction.reply({embeds:[embed('إحصائيات الأعضاء',`عدد الأعضاء الحالي: **${interaction.guild.memberCount}**`) ]});
   if(commandName==='suggest'||commandName==='report') {
    const details=interaction.options.getString(commandName==='suggest'?'text':'details');
    const title=commandName==='suggest'?'💡 اقتراح جديد':'🚨 بلاغ جديد';
    await log(interaction.guild,title,`من: ${interaction.user} (${interaction.user.tag})\nالمحتوى: ${details}`);
    if(commandName==='suggest') await interaction.channel.send({embeds:[embed('💡 اقتراح من المجتمع',`**من:** ${interaction.user}\n**الاقتراح:** ${details}`).setFooter({text:`User ID: ${interaction.user.id}`})]});
    return interaction.reply({content:commandName==='suggest'?'تم إرسال اقتراحك.':'تم إرسال البلاغ إلى الإدارة. لو قناة اللوجات غير مضبوطة، اضبط logsChannelId في config.json.',ephemeral:true});
   }
   if(commandName==='dm-optin'||commandName==='dm-optout') {
    const db=store.read(); db.dmSubscribers=Array.isArray(db.dmSubscribers)?db.dmSubscribers:[];
    if(commandName==='dm-optin') { if(!db.dmSubscribers.includes(interaction.user.id)) db.dmSubscribers.push(interaction.user.id); store.write(db); return interaction.reply({content:'اشتركت في إعلانات الخاص الاختيارية. تقدر تلغي الاشتراك في أي وقت باستخدام `/dm-optout`.',ephemeral:true}); }
    db.dmSubscribers=db.dmSubscribers.filter(id=>id!==interaction.user.id); store.write(db); return interaction.reply({content:'تم إلغاء اشتراكك في إعلانات الخاص.',ephemeral:true});
   }
   if(commandName==='dm-all') {
    if(!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) return interaction.reply({content:'الأمر للإدارة فقط.',ephemeral:true});
    const message=interaction.options.getString('message'); const db=store.read(); const ids=[...new Set(Array.isArray(db.dmSubscribers)?db.dmSubscribers:[])];
    await interaction.reply({content:`بدأ إرسال الإعلان للمشتركين فقط (${ids.length} مشترك). قد لا تصل الرسالة لمن أغلق الخاص.`,ephemeral:true});
    let sent=0, failed=0;
    for(const id of ids) { try { const user=await client.users.fetch(id); if(user.bot) continue; await user.send({embeds:[embed('إعلان Nova RolePlay',message),new EmbedBuilder().setColor(color).setDescription('لإيقاف إعلانات الخاص استخدم `/dm-optout` داخل السيرفر.') ]}); sent++; } catch { failed++; } await new Promise(r=>setTimeout(r,1200)); }
    await log(interaction.guild,'إعلان خاص للمشتركين',`بواسطة ${interaction.user.tag}\nنجح: ${sent}\nتعذر: ${failed}`); return log(interaction.guild,'اكتمل إرسال الإعلان',`بواسطة ${interaction.user.tag} — نجاح ${sent} — فشل ${failed}`);
   }
   if(commandName==='say') {
    if(!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageMessages)) return interaction.reply({content:'تحتاج صلاحية إدارة الرسائل.',ephemeral:true});
    await interaction.channel.send({content:interaction.options.getString('message').replace(/@everyone/g,'@\u200beveryone').replace(/@here/g,'@\u200bhere'),allowedMentions:{parse:[]}}); return interaction.reply({content:'تم إرسال الرسالة.',ephemeral:true});
   }
   if(commandName==='embed') {
    if(!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageMessages)) return interaction.reply({content:'تحتاج صلاحية إدارة الرسائل.',ephemeral:true});
    const title=interaction.options.getString('title'), description=interaction.options.getString('description'); await interaction.channel.send({embeds:[embed(title,description)]}); return interaction.reply({content:'تم نشر الرسالة المنسقة.',ephemeral:true});
   }
   if(commandName==='timeout'||commandName==='untimeout') {
    if(!interaction.memberPermissions?.has(PermissionsBitField.Flags.ModerateMembers)) return interaction.reply({content:'تحتاج صلاحية Timeout Members.',ephemeral:true});
    const user=interaction.options.getUser('member'); const member=await interaction.guild.members.fetch(user.id).catch(()=>null); if(!member) return interaction.reply({content:'العضو غير موجود في السيرفر.',ephemeral:true});
    if(member.id===interaction.guild.ownerId || member.roles.highest.position>=interaction.member.roles.highest.position) return interaction.reply({content:'لا يمكن تعديل هذا العضو بسبب ترتيب الرتب.',ephemeral:true});
    const reason=interaction.options.getString('reason')||`بواسطة ${interaction.user.tag}`;
    if(commandName==='timeout') { const minutes=interaction.options.getInteger('minutes'); await member.timeout(minutes*60000,reason); await interaction.reply({content:`تم إسكات ${user.tag} لمدة ${minutes} دقيقة.`}); }
    else { await member.timeout(null,reason); await interaction.reply({content:`تم إلغاء إسكات ${user.tag}.`}); }
    await log(interaction.guild,commandName==='timeout'?'إسكات عضو':'إلغاء إسكات عضو',`${user.tag} — ${reason} — بواسطة ${interaction.user.tag}`); return;
   }
   if(commandName==='nickname') {
    const user=interaction.options.getUser('member'); const name=interaction.options.getString('name'); const member=await interaction.guild.members.fetch(user.id).catch(()=>null); if(!member) return interaction.reply({content:'العضو غير موجود.',ephemeral:true});
    if(member.id===interaction.guild.ownerId || member.roles.highest.position>=interaction.member.roles.highest.position) return interaction.reply({content:'لا يمكن تغيير لقب هذا العضو بسبب ترتيب الرتب.',ephemeral:true});
    await member.setNickname(name,`بواسطة ${interaction.user.tag}`); await interaction.reply({content:`تم تغيير لقب ${user.tag}.`}); await log(interaction.guild,'تغيير لقب',`${user.tag} ← ${name} — بواسطة ${interaction.user.tag}`); return;
   }
   if(commandName==='roleinfo') { const role=interaction.options.getRole('role'); return interaction.reply({embeds:[embed(`معلومات الرتبة: ${role.name}`,`**المعرف:** \`${role.id}\`\n**الأعضاء:** ${role.members.size}\n**اللون:** ${role.hexColor}\n**مذكورة:** ${role.mentionable?'نعم':'لا'}\n**منشأة:** <t:${Math.floor(role.createdTimestamp/1000)}:F>`)] ,ephemeral:true}); }
   if(commandName==='channelinfo') { const ch=interaction.channel; return interaction.reply({embeds:[embed('معلومات القناة',`**القناة:** ${ch}\n**الاسم:** ${ch.name}\n**المعرف:** \`${ch.id}\`\n**النوع:** ${ChannelType[ch.type]||ch.type}\n**تاريخ الإنشاء:** <t:${Math.floor(ch.createdTimestamp/1000)}:F>`)],ephemeral:true}); }
   if(commandName==='remind') {
    const minutes=interaction.options.getInteger('minutes'), text=interaction.options.getString('text'); await interaction.reply({content:`تمام، هفكّرك بعد ${minutes} دقيقة في الخاص لو الرسائل مفتوحة.`,ephemeral:true});
    setTimeout(async()=>{ try { await interaction.user.send({embeds:[embed('⏰ تذكير Nova',text)]}); } catch {} },minutes*60000); return;
   }
   if(commandName==='giveaway') {
    if(!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) return interaction.reply({content:'الأمر للإدارة فقط.',ephemeral:true});
    const prize=interaction.options.getString('prize'), minutes=interaction.options.getInteger('minutes'); const endAt=Date.now()+minutes*60000;
    const msg=await interaction.channel.send({embeds:[embed('🎉 سحب Nova RolePlay',`**الجائزة:** ${prize}\n**ينتهي:** <t:${Math.floor(endAt/1000)}:R>\nاضغط 🎉 للمشاركة!`)]}); await msg.react('🎉'); await interaction.reply({content:`تم إنشاء السحب: ${msg.url}`,ephemeral:true});
    setTimeout(async()=>{ try { const fetched=await msg.fetch(); const reaction=fetched.reactions.cache.get('🎉'); const users=reaction?await reaction.users.fetch():null; const entrants=users?[...users.values()].filter(u=>!u.bot):[]; if(!entrants.length) return fetched.reply('انتهى السحب، لم يشارك أحد.'); const winner=entrants[Math.floor(Math.random()*entrants.length)]; await fetched.reply({content:`🎉 مبروك ${winner}! فزت بـ **${prize}**!`}); await log(interaction.guild,'انتهاء السحب',`الجائزة: ${prize}\nالفائز: ${winner.tag}`); } catch {} },minutes*60000); return;
   }
   if(commandName==='ticket-panel') { if(!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) return interaction.reply({content:'للإدارة فقط.',ephemeral:true}); await interaction.channel.send({embeds:[embed(config.tickets.panelTitle,config.tickets.panelDescription)],components:[ticketMenu()]}); return interaction.reply({content:'تم نشر لوحة التذاكر.',ephemeral:true}); }
  }
  if(interaction.isStringSelectMenu() && interaction.customId==='nova_ticket_create') {
   await interaction.deferReply({ephemeral:true}); const guild=interaction.guild; const db=store.read(); const existing=guild.channels.cache.find(c=>c.type===ChannelType.GuildText && c.topic?.includes(`OWNER:${interaction.user.id}`) && c.topic?.includes('NOVA_TICKET')); if(existing) return interaction.editReply(`عندك تذكرة مفتوحة بالفعل: ${existing}`);
   const idx=Number(interaction.values[0].replace('type_','')); const type=config.tickets.types[idx]||'دعم فني'; const num=String(db.nextTicket++).padStart(4,'0'); store.write(db);
   const overwrites=[{id:guild.roles.everyone.id,deny:[PermissionsBitField.Flags.ViewChannel]},{id:interaction.user.id,allow:[PermissionsBitField.Flags.ViewChannel,PermissionsBitField.Flags.SendMessages,PermissionsBitField.Flags.ReadMessageHistory,PermissionsBitField.Flags.AttachFiles]},{id:client.user.id,allow:[PermissionsBitField.Flags.ViewChannel,PermissionsBitField.Flags.SendMessages,PermissionsBitField.Flags.ReadMessageHistory,PermissionsBitField.Flags.ManageChannels]}]; if(config.roles.staffRoleId) overwrites.push({id:config.roles.staffRoleId,allow:[PermissionsBitField.Flags.ViewChannel,PermissionsBitField.Flags.SendMessages,PermissionsBitField.Flags.ReadMessageHistory]});
   const opts={name:`ticket-${num}`,type:ChannelType.GuildText,topic:`NOVA_TICKET | OWNER:${interaction.user.id} | NUMBER:${num} | TYPE:${type}`,permissionOverwrites:overwrites}; if(config.channels.ticketCategoryId) { const cat=await guild.channels.fetch(config.channels.ticketCategoryId).catch(()=>null); if(cat?.type===ChannelType.GuildCategory) opts.parent=cat.id; }
   const ch=await guild.channels.create(opts); const row=new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('nova_ticket_close').setLabel('إغلاق التذكرة').setStyle(ButtonStyle.Danger)); await ch.send({content:`${interaction.user}${config.roles.staffRoleId?` <@&${config.roles.staffRoleId}>`:''}`,embeds:[embed(`تذكرة #${num} — ${type}`,`أهلًا ${interaction.user}، اشرح مشكلتك بالتفصيل وسيقوم فريق Nova بمساعدتك.\n\n**النوع:** ${type}\n**رقم التذكرة:** ${num}`)],components:[row]}); await interaction.editReply(`تم فتح تذكرتك: ${ch}`); await log(guild,'تذكرة جديدة',`#${num} — ${type} — ${interaction.user.tag} — ${ch}`); return;
  }
  if(interaction.isButton() && interaction.customId==='nova_ticket_close') { if(!interaction.channel?.topic?.includes('NOVA_TICKET')) return interaction.reply({content:'دي مش قناة تذكرة.',ephemeral:true}); const owner=(interaction.channel.topic.match(/OWNER:(\d+)/)||[])[1]; if(interaction.user.id!==owner && !hasStaff(interaction.member)) return interaction.reply({content:'صاحب التذكرة أو فريق الدعم فقط يقدر يقفلها.',ephemeral:true}); await interaction.reply({content:'سيتم إغلاق التذكرة بعد 5 ثواني.'}); await log(interaction.guild,'إغلاق تذكرة',`${interaction.user.tag} أغلق ${interaction.channel.name}`); setTimeout(()=>interaction.channel.delete().catch(()=>{}),5000); }
 } catch(error) { console.error('Nova bot interaction error:', error?.stack || error); const msg='حصل خطأ أثناء تنفيذ الأمر. راجع Console وإعدادات القنوات والرتب.'; if(interaction.isRepliable()) { if(interaction.deferred) await interaction.editReply({content:msg}).catch(()=>{}); else if(!interaction.replied) await interaction.reply({content:msg,ephemeral:true}).catch(()=>{}); } }
});
client.login(process.env.DISCORD_TOKEN);
