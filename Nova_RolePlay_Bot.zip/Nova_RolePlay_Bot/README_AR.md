# Nova RolePlay Discord Bot

بوت Discord أساسي متكامل لسيرفر Nova RolePlay / MTA، مبني على Node.js وdiscord.js v14.

## الأنظمة الموجودة
- لوحة تذاكر بقائمة أنواع قابلة للتعديل، قناة خاصة لكل تذكرة، إغلاق بزر، ترقيم متسلسل محفوظ في `data/store.json`.
- أوامر إدارية: `/warn`, `/warnings`, `/clear`, `/kick`, `/ban`, `/timeout`, `/untimeout`, `/nickname`, `/announce`, `/say`, `/embed`, `/giveaway`, `/dm`, `/dm-all`, `/lock`, `/unlock`, `/slowmode`, `/role-add`, `/role-remove`, `/poll`, `/setup-ticket`, `/ticket-panel`.
- أوامر الأعضاء: `/help`, `/ping`, `/botinfo`, `/membercount`, `/userinfo`, `/serverinfo`, `/avatar`, `/roleinfo`, `/channelinfo`, `/suggest`, `/report`, `/remind`, `/dm-optin`, `/dm-optout`.
- ترحيب ومغادرة عند ضبط معرفات القنوات.
- لوجات للإجراءات والتذاكر عند ضبط قناة اللوجات.
- `/server-status` لعرض حالة MTA عند تفعيل الإعدادات.

## تشغيل محلي أو على استضافة Node.js
1. ثبّت Node.js 20 أو أحدث.
2. انسخ `.env.example` إلى ملف اسمه `.env`.
3. ضع توكن البوت في `DISCORD_TOKEN` ومعرّف التطبيق في `CLIENT_ID` ومعرّف السيرفر في `GUILD_ID`.
4. في Discord Developer Portal فعّل Server Members Intent إذا احتجت الترحيب/المغادرة، وأضف البوت بصلاحيات إدارة القنوات والرسائل والرتب اللازمة.
5. شغّل `npm install`.
6. شغّل `npm run deploy` لتسجيل أوامر السلاش.
7. شغّل `npm start`.

بعد إضافة أو تحديث الأوامر، شغّل `npm run deploy` مرة أخرى ثم أعد تشغيل البوت. أمر `/dm` يرسل لعضو محدد. أمر `/dm-all` يرسل فقط للمستخدمين الذين اشتركوا صراحة عبر `/dm-optin`؛ يمكنهم الإلغاء عبر `/dm-optout`. قد يفشل الخاص إذا كان مغلقًا، والإرسال يتوقف على توفر البوت واستمرار تشغيله.
8. ارفع المشروع كاملًا إلى استضافة تدعم Node.js، واجعل أمر التشغيل `npm start` وأضف متغيرات `.env` من لوحة الاستضافة.

## إعداد القنوات والرتب
افتح `config.json` وضع IDs الصحيحة بدل النصوص الفارغة:
- `welcomeChannelId`: قناة الترحيب.
- `leaveChannelId`: قناة المغادرة.
- `logsChannelId`: قناة اللوجات.
- `ticketCategoryId`: كاتيجوري التذاكر (اختياري؛ اتركه فارغًا لو مش عايز كاتيجوري).
- `staffRoleId`: رتبة الدعم التي ترى التذاكر.
- `adminRoleId`: رتبة الإدارة.
- `transcriptChannelId`: محفوظ للإعدادات المستقبلية؛ تصدير transcript غير مطبق في هذه النسخة.

لتفعيل حالة MTA، اجعل `mta.enabled` إلى `true` واضبط `host` و`port`.

## مهم
- لا ترفع ملف `.env` إلى GitHub ولا ترسل التوكن لأي شخص.
- هذه نسخة بداية عملية؛ لا تتضمن بعد جسر تذاكر بين سيرفرين أو نسخ المحادثة/المرفقات بينهما، ولا نظام اقتصاد/رتب تلقائي داخل MTA. يلزم تطوير منفصل لهذه الوظائف.
